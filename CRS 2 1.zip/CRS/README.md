
# Requirement
Download any web server on your computer such as wamp, xampp ...etc
import demo.sql file into your database (MySQL)

The MySQL  username must be root


 ```
¦   index.php
¦   login.php
¦   README.md
¦
+---admin
¦   ¦   config.php
¦   ¦   index.php
¦   ¦   user_add.php
¦   ¦   user_delete.php
¦   ¦   user_edit.php
¦   ¦
¦   +---layouts
¦           config.php
¦           logout.php
¦
+---assets
¦   +---css
¦   ¦   ¦   own.css
¦   ¦   ¦   style.css
¦   ¦   ¦
¦   ¦   +---admin
¦   ¦   ¦   +---assets
¦   ¦   ¦       +---fonts
¦   ¦   +---lib
¦   +---fonts
¦   +---images
¦   +---js
¦       +---lib
+---university
¦   ¦   add_student.php
¦   ¦   config.php
¦   ¦   index.php
¦   ¦   user_delete.php
¦   ¦
¦   +---layouts
¦           config.php
¦           header.php
¦           logout.php
¦           sidebar.php
¦
+---company
¦       config.php
¦       co_add.php
¦       index.php
¦
+---inc
¦       config pdo.php
¦       config.php
¦
+---layouts
¦       config.php
¦       header.php
¦       logout.php
¦       sidebar.php
¦
+---student
¦   ¦   config.php
¦   ¦   index.php
¦   ¦   student_bio.php
¦   ¦
¦   +---layouts
¦           config.php
¦           header.php
¦           logout.php
¦           sidebar.php
¦
+---uploads
 ```
