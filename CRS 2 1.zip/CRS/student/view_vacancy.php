<header class="masthead">
    <div class="container-fluid h-100">
        <div class="row h-100 align-items-center justify-content-center text-center">
            <!-- Content for header can be added here -->
        </div>
    </div>
</header>

<section id="">
    <?php
    $conn = new mysqli('localhost', 'root', '', 'dola') or die('Cannot connect to db');

    // Fetch data from the database based on the company ID
    $companyId = ?; // replace with the actual company ID
    $sql = "SELECT * FROM tbl_company WHERE id = 7";
    
    // Use prepared statement with bind_param
    $query = $conn->prepare($sql);

    if (!$query) {
        echo "Error preparing query: " . $conn->error;
    } else {
        $query->bind_param('i', $companyId); // 'i' indicates integer type, adjust accordingly if it's a different type
        $query->execute();

        if ($query->error) {
            echo "Error executing query: " . $query->error;
        } else {
            $result = $query->get_result();

            if ($result->num_rows > 0) {
                $companyData = $result->fetch_assoc();

                // Extracting variables from the associative array
                extract($companyData);
                ?>
                <div class="container mb-2 pt-4 ">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <h4 class="text-center"><b><?php echo $cp_position; ?></b></h4>
                                    <hr class="divider" style="max-width: calc(10%)">
                                    <p class="text-center">
                                        <small>
                                            <i><b>Needed: <larger><?php echo $cp_position; ?></larger></b></i>
                                        </small>
                                        
                                    </p>
                                </div>
                            </div>
                            <hr class="divider" style="max-width: calc(100%)">
                            <div class="row">
                                <div class="col-lg-12">
                                    <?php echo html_entity_decode($job_details); ?>
                                </div>
                            </div>
                            <hr class="divider" style="max-width: calc(100%)">
                            <div class="row">
                                <div class="col-lg-12">
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
            } else {
                echo "Company not found. Check the provided ID: $companyId";
            }
        }
    }
    ?>
</section>

<script>
    $('html, body').animate({
        scrollTop: ($('section').offset().top - 72)
    }, 1000);
    $('#apply_now').click(function () {
        uni_modal('Application from', 'submit_application.php?id=<?php echo $companyId; ?>', 'large');
    })
</script>
