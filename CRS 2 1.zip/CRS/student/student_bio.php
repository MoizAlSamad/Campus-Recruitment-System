<?php
include("config.php");

$name = $_POST['st_Name'];
$email = $_POST['st_Email'];
$phone = $_POST['st_Phone'];
$address = $_POST['st_Address'];
$cv = $_FILES["st_Cv"]["name"];
$company_name = isset($_POST['cp_name']) ? $_POST['cp_name'] : '';
$gender = isset($_POST['st_gender']) ? $_POST['st_gender'] : '';
$cp_position = isset($_POST['cp_position']) ? $_POST['cp_position'] : '';

$target_path = "./uploads/";
$target_path = $target_path . basename($_FILES['st_Cv']['name']);

if (move_uploaded_file($_FILES['st_Cv']['tmp_name'], $target_path)) {
    echo "File uploaded successfully!";
} else {
    echo "Sorry, file not uploaded, please try again!";
}

$sql = "INSERT INTO students (name, email, phone, address, cv, company_name, gender, company_position) VALUES (:name, :email, :phone, :address, :cv, :company_name, :gender, :company_position)";
$query = $dbConn->prepare($sql);
$query->bindParam(':name', $name);
$query->bindParam(':email', $email);
$query->bindParam(':phone', $phone);
$query->bindParam(':address', $address);
$query->bindParam(':cv', $cv);
$query->bindParam(':company_name', $company_name);
$query->bindParam(':gender', $gender);
$query->bindParam(':company_position', $cp_position); // Bind the company position parameter

$query->execute();
$dbConn = null;

header("Location:../student/index.php");
?>


