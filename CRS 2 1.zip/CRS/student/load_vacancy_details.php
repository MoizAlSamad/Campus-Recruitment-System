<?php
// database connection code here
require_once('../inc/config.php');

// Check if the 'id' parameter is set and is a valid integer
if (isset($_POST['id']) && filter_var($_POST['id'], FILTER_VALIDATE_INT)) {
    $companyId = $_POST['id'];

    try {
        $query = $dbConn->prepare("SELECT * FROM tbl_company WHERE id = :id");
        $query->bindParam(':id', $companyId, PDO::PARAM_INT);
        $query->execute();

        // Fetch the data as an associative array
        $companyData = $query->fetch(PDO::FETCH_ASSOC);

        // Check if any data was retrieved
        if ($companyData !== false) {
            // Return the data as JSON (assuming your JavaScript expects JSON)
            echo json_encode($companyData);
        } else {
            // Handle the case where no data was found for the given ID
            echo json_encode(['error' => 'No data found for the provided ID']);
        }
    } catch (PDOException $e) {
        // Handle any database errors
        echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    // Handle invalid or missing parameters
    echo json_encode(['error' => 'Invalid or missing parameters']);
}
?>
