<?php
session_start();

if (!isset($_SESSION['id'], $_SESSION['user_role_id'])) {
    header('location: admin/index.php?lmsg=true');
    exit;
}

require_once('../inc/config.php');

// Assuming  config.php file contains database connection details
try {
    $dbConn = new PDO("mysql:host=localhost;dbname=dola", "root", "");
    $dbConn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Search filter
    $search = isset($_GET['search']) ? $_GET['search'] : '';
    $searchCondition = empty($search) ? '' : "WHERE cp_name LIKE '%$search%' OR cp_position LIKE '%$search%' OR job_details LIKE '%$search%'";

    // Pagination
    $limit = isset($_GET['limit']) ? $_GET['limit'] : 10;
    $page = isset($_GET['page']) ? $_GET['page'] : 1;
    $offset = ($page - 1) * $limit;
    
    // Fetch data with search and pagination
    $query = $dbConn->query("SELECT * FROM tbl_company $searchCondition LIMIT $offset, $limit");
    $companyData = $query->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CRS Student : Dashboard</title>
    <!-- Favicon -->
    <link rel="shortcut icon" href="http://placehold.it/64.png/000/fff">
    <!-- Styles -->

    <link href="../assets/css/lib/font-awesome.min.css" rel="stylesheet">
    <link href="../assets/css/lib/themify-icons.css" rel="stylesheet">
    <link href="../assets/css/lib/owl.carousel.min.css" rel="stylesheet" />
    <link href="../assets/css/lib/owl.theme.default.min.css" rel="stylesheet" />
    <link href="../assets/css/lib/menubar/sidebar.css" rel="stylesheet">
    <link href="../assets/css/lib/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/lib/unix.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <link href="../assets/css/own.css" rel="stylesheet">
    
</head>

<body class="sidebar-hide" >
        <?php require_once('../layouts/sidebar.php'); ?>
        <?php require_once('../layouts/header.php'); ?>

        <div class="content-wrap">
            <div class="main">
                <div class="container-fluid">
                    

                    <!-- Vacancy List Card -->
                    <div class="card">
                        <div class="card-header">
                            <div class="row">
                                <div class="col-lg-12">
                                    <span><large><b>Vacancy List</b></large></span>
                                    <header class="btn btn-sm btn-block btn-primary btn-sm col-md-2 float-right"  id="new_vacancy">
                                          Vacancy
                                    </header>
                                </div>
                            </div>
                        </div>

                        <!-- Search Form -->
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12 text-left">
                                    <form class="form-inline" action="" method="get">
                                        <div class="input-group">
                                            <input type="text" class="form-control" placeholder="Search" name="search" value="<?= htmlspecialchars($search) ?>">
                                            <div class="input-group-append">
                                                <button class="btn btn-sm btn-block btn-primary btn-sm col-md-2 float-right" type="submit">Search</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>

                            <!-- Page Limit Selection -->
                            <div class="row">
                                <div class="col-md-12 text-right">
                                    <label for="limit">Show:</label>
                                    <select id="limit" class="form-control" onchange="changePageLimit(this.value)">
                                        <option value="10" <?= $limit == 10 ? 'selected' : '' ?>>10</option>
                                        <option value="25" <?= $limit == 25 ? 'selected' : '' ?>>25</option>
                                        <option value="100" <?= $limit == 100 ? 'selected' : '' ?>>100</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <!-- Pagination -->
                        <div class="col-md-12 text-center">
                            <ul class="pagination">
                                <?php
                                // Calculate total pages based on the number of records and page limit
                                $totalPages = ceil(count($companyData) / $limit);

                                // Generate pagination links
                                for ($i = 1; $i <= $totalPages; $i++) {
                                    // Highlight the current page
                                    echo '<li class="page-item ' . ($page == $i ? 'active' : '') . '"><a class="page-link" href="?page=' . $i . '&limit=' . $limit . '&search=' . $search . '">' . $i . '</a></li>';
                                }
                                ?>
                            </ul>
                        </div>

                        <!-- Vacancy List Table -->
                        <div class="card-body">
                            <table class="table table-bordered table-hover">
                                <colgroup>
                                    <col width="10%">
                                    <col width="40%">
                                    <col width="20%">
                                    <col width="10%">
                                    <col width="20%">
                                </colgroup>
                                <thead>
                                    <tr>
                                        <th class="text-center">#</th>
                                        <th class="text-center">Company Information</th>
                                        <th class="text-center">Availability</th>
                                        <th class="text-center">Status</th>
                                        <th class="text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                        <?php foreach ($companyData as $index => $row): ?>
                            <tr>
                                <td class="text-center"><?php echo $index + 1; ?></td>
                                <td class="">
                                    <p>Company Name : <b><?php echo $row['cp_name']; ?></b></p>
                                    <p>Position : <b><?php echo $row['cp_position']; ?></b></p>
                                    <p class="truncate"><i><small><?php echo $row['job_details']; ?></small></i></p>
                                </td>
                                <td class="text-center">
                                    <p><b><?php echo $row['can_number']; ?></b></p>
                                </td>
                                <td class="text-center">
                                    <span class="badge badge-success">Active</span>
                                </td>
                                <td class="text-center">
                                <a class="btn btn-sm btn-success" href="view_vacancy.php?id=<?php echo $row['id']; ?>">View</a>
                                    <a class="btn btn-sm btn-success" href="apply.php?id=<?php echo $row['id']; ?>">Apply</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    <!-- External Scripts -->
    <script src="../assets/js/lib/jquery.min.js"></script>
    <script src="../assets/js/lib/bootstrap.min.js"></script>
    <script src="../assets/js/lib/mmc-common.js"></script>
    <script src="../assets/js/lib/datamap/d3.min.js"></script>
    <script src="../assets/js/lib/datamap/topojson.js"></script>
    <script src="../assets/js/lib/datamap/datamaps.world.min.js"></script>
    <script src="../assets/js/lib/datamap/datamap-init.js"></script>
    <script src="../assets/js/lib/weather/jquery.simpleWeather.min.js"></script>
    <script src="../assets/js/lib/owl-carousel/owl.carousel.min.js"></script>
    <script src="../assets/js/lib/owl-carousel/owl.carousel-init.js"></script>
    <script src="../assets/js/scripts.js"></script>

    <!-- Custom Script -->
    <script>
        // Function to change page limit
        function changePageLimit(limit) {
            // Redirect to the first page with the new page limit
            window.location.href = '?limit=' + limit + '&search=<?= htmlspecialchars($search) ?>&page=1';
        }

        // Document ready function
        $(document).ready(function () {
            // Handle form submission when the user presses Enter in the search input
            $('#limit').on('change', function () {
                // Trigger change in page limit
                changePageLimit($(this).val());
            });

            var companyId;

            // Modal Show Event
            $('#vacancyModal').on('show.bs.modal', function (event) {
                var button = $(event.relatedTarget);
                companyId = button.data('id');
                var action = 'view'; // Always set action to 'view' for displaying details

                // Ajax request to load vacancy details
                $.ajax({
                    type: 'POST',
                    url: 'load_vacancy_details.php',
                    data: { id: companyId, action: action },
                    dataType: 'json',
                    success: function (response) {
                        // Populate modal with data
                        populateModal(response, true);
                    },
                    error: function (error) {
                        console.error('Error loading data: ', error);
                    }
                });
            });

            // Function to populate modal content
            function populateModal(data, isViewMode) {
                $('#vacancyModalLabel').text(data.position);
                $('#modalContent').html(`
                    <!-- ... (existing modal content) -->
                `);

                if (isViewMode) {
                    $('.form-control').prop('disabled', true);
                    $('input[type=submit]').hide();
                }

                // Show the modal
                $('#vacancyModal').modal('show');
            }
        });
    </script>

</body>
</html>

