<?php
include("config.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $cp_name = $_POST['cp_name'];
    // Add other form elements for editing

    $query = $dbConn->prepare("UPDATE tbl_company SET cp_name = :cp_name WHERE id = :id");
    $query->bindParam(":id", $id);
    $query->bindParam(":cp_name", $cp_name);
    // Bind other parameters for editing

    try {
        if ($query->execute()) {
            echo json_encode(["success" => "Vacancy updated successfully"]);
        } else {
            echo json_encode(["error" => "Error updating vacancy"]);
        }
    } catch (Exception $e) {
        echo json_encode(["error" => "Exception: " . $e->getMessage()]);
    }
} else {
    echo json_encode(["error" => "Invalid request method"]);
}
?>


