<?php
include("config.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];

    $query = $dbConn->prepare("DELETE FROM tbl_company WHERE id = :id");
    $query->bindParam(":id", $id);

    try {
        if ($query->execute()) {
            echo json_encode(["success" => "Vacancy deleted successfully"]);
        } else {
            echo json_encode(["error" => "Error deleting vacancy"]);
        }
    } catch (Exception $e) {
        echo json_encode(["error" => "Exception: " . $e->getMessage()]);
    }
} else {
    echo json_encode(["error" => "Invalid request method"]);
}
?>

