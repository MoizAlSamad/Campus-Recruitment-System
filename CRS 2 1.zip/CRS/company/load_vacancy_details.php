<?php
include("config.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $action = $_POST['action'];

    if ($action == "view" || $action == "edit") {
        $query = $dbConn->prepare("SELECT * FROM tbl_company WHERE id = :id");
        $query->bindParam(":id", $id);

        try {
            $query->execute();
            $vacancyData = $query->fetch(PDO::FETCH_ASSOC);

            if ($vacancyData !== false && $vacancyData !== null) {
                echo json_encode($vacancyData);
            } else {
                echo json_encode(["error" => "Record not found"]);
            }
        } catch (Exception $e) {
            echo json_encode(["error" => "Exception: " . $e->getMessage()]);
        }
    } else {
        echo json_encode(["error" => "Invalid action"]);
    }
} else {
    echo json_encode(["error" => "Invalid request method"]);
}
?>

