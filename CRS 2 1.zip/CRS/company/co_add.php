<?php
include("config.php");

try {
    // Ensure that the form fields are set and not empty
    $id = isset($_POST['in_Id']) ? $_POST['in_Id'] : null;
    $cp_name = isset($_POST['in_CpName']) ? $_POST['in_CpName'] : null;
    $cp_position = isset($_POST ['in_Position'])? $_POST['in_Position']:null;
    $qualification = isset($_POST['Qualification']) ? $_POST['Qualification'] : null;
    $can_number = isset($_POST['in_CanNum']) ? $_POST['in_CanNum'] : null;
    $job_details = isset($_POST['in_JobDetails']) ? $_POST['in_JobDetails'] : null;
    $salary = isset($_POST['in_Salary']) ? $_POST['in_Salary'] : null;
    $insurance = isset($_POST['in_Insurance']) ? $_POST['in_Insurance'] : null;
    $resident = isset($_POST['in_Resident']) ? $_POST['in_Resident'] : null;
    $email = isset($_POST['in_Email']) ? $_POST['in_Email'] : null;


    // Check if cp_name is not empty
    if (empty($cp_name)) {
        throw new Exception("Company name cannot be empty.");
    }

    $sql = "INSERT INTO tbl_company (id, cp_name, cp_position, can_number, job_details, salary, qualification, insurance, email, resident) VALUES (:id, :cp_name, :cp_position, :can_number, :job_details, :salary, :qualification, :insurance, :email, :resident)";

    $query = $dbConn->prepare($sql);

    $query->bindParam(':id', $id);
    $query->bindParam(':cp_name', $cp_name);
    $query->bindParam(':cp_position', $cp_position);
    $query->bindParam(':qualification', $qualification);
    $query->bindParam(':can_number', $can_number);
    $query->bindParam(':job_details', $job_details);
    $query->bindParam(':salary', $salary);
    $query->bindParam(':insurance', $insurance);
    $query->bindParam(':resident', $resident);
    $query->bindParam(':email', $email);


    if ($query->execute()) {
        header("Location:../company/index.php");
    } else {
        echo "Error executing insert query: " . $query->error;
    }
} catch (Exception $e) {
    echo "An error occurred: " . $e->getMessage();
}
?>
