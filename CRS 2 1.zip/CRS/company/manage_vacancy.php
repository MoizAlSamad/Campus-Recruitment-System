<?php
include("config.php");

// Check if the form is submitted for updating or adding a new company
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle form submission
    if (isset($_POST['id'])) {
        // Update existing company
        $stmt = $dbConn->prepare("UPDATE tbl_company SET cp_name = :cp_name, cp_position = :cp_position, can_number = :can_number, job_details = :job_details, salary = :salary, qualification = :qualification, insurance = :insurance, resident = :resident, email = :email WHERE id = :id");
    } else {
        // Insert new company
        $stmt = $dbConn->prepare("INSERT INTO tbl_company (cp_name, cp_position, can_number, job_details, salary, qualification, insurance, resident, email) VALUES (:cp_name, :cp_position, :can_number, :job_details, :salary, :qualification, :insurance, :resident, :email)");
    }

    // Bind parameters
    $stmt->bindParam(':id', $_POST['in_Id']);
    $stmt->bindParam(':cp_name', $_POST['in_CpName']);
    $stmt->bindParam(':cp_position', $_POST['in_Position']);
    $stmt->bindParam(':qualification', $_POST['Qualification']);
    $stmt->bindParam(':can_number', $_POST['in_CanNum']);
    $stmt->bindParam(':job_details', $_POST['in_JobDetails']);
    $stmt->bindParam(':salary', $_POST['in_Salary']);
    $stmt->bindParam(':insurance', $_POST['in_Insurance']);
    $stmt->bindParam(':resident', $_POST['in_Resident']);
    $stmt->bindParam(':email', $_POST['in_Email']);

    // If updating, bind company ID
    if (isset($_POST['id'])) {
        $stmt->bindParam(':id', $_POST['id']);
    }

    // Execute the statement
    $stmt->execute();

    // Output success response
    echo 1;
    exit;
}

// Assuming you have a method to retrieve company data from the database
if (isset($_GET['id'])) {
    $stmt = $dbConn->prepare("SELECT * FROM tbl_company WHERE id = :id");
    $stmt->bindParam(':id', $_GET['id']);
    $stmt->execute();
    $company = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($company) {
        extract($company);
    }
}
?>

<!-- ... (your existing PHP code) ... -->

<div class="container-fluid">
<form action="" id="manage-vacancy-form">
        <input type="hidden" name="id" value="<?= isset($_GET['id']) ? $_GET['id'] : '' ?>" class="form-control">
        <div class="row form-group">
            <div class="col-md-8">
                <label class="control-label">Company Name</label>
                <input type="text" name="cp_name" class="form-control" value="<?= isset($cp_name) ? $cp_name : '' ?>">
            </div>
        </div>
        <div class="row form-group">
            <div class="col-md-8">
                <label class="control-label">Position</label>
                <input type="text" name="cp_position" class="form-control" value="<?= isset($cp_position) ? $cp_position : '' ?>">
            </div>
        </div>
        <!-- Add other fields as needed -->

        <div class="row form-group">
            <div class="col-md-12">
			<button type="submit" class="btn btn-primary">Save Vacancy</button>
            </div>
        </div>
    </form>
</div>

<script>
        $('#manage-vacancy-form').submit(function (e) {
            e.preventDefault();
            start_load();
            $.ajax({
                url: 'manage_vacancy.php',
                method: 'POST',
                data: $(this).serialize(),
                success: function (resp) {
                    if (resp == 1) {
                        alert_toast("Data successfully saved.", 'success');
                        setTimeout(function () {
                            location.reload();
                        }, 1000);
                    }
                }
            });
        });
    </script>
