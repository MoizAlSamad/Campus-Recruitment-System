<?php
session_start();

if (!isset($_SESSION['id'], $_SESSION['user_role_id'])) {
    header('location:admin/index.php?lmsg=true');
    exit;
}

require_once('../inc/config.php');

// Database Connection
$conn = new mysqli('localhost', 'root', '', 'dola') or die('Cannot connect to db');

// Fetch Company Names
$resul = $conn->query("SELECT * FROM tbl_users WHERE user_role_id LIKE '%2%'");

// Fetch Vacancies
$qry = $conn->query("SELECT * FROM vacancy");
while ($row = $qry->fetch_assoc()) {
    $pos[$row['id']] = $row['position'];
}

// Fetch Recruitment Status
$stats = $conn->query("SELECT * FROM recruitment_status order by id asc");
$stat_arr[0] = "New";
while ($row = $stats->fetch_assoc()) {
    $stat_arr[$row['id']] = $row['status_label'];
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Company Admin : Dashboard</title>
    <!-- ================= Favicon ================== -->
    <!-- Standard -->
    <link rel="shortcut icon" href="http://placehold.it/64.png/000/fff">
    <!-- Retina iPad Touch Icon-->
    <link rel="apple-touch-icon" sizes="144x144" href="http://placehold.it/144.png/000/fff">
    <!-- Retina iPhone Touch Icon-->
    <link rel="apple-touch-icon" sizes="114x114" href="http://placehold.it/114.png/000/fff">
    <!-- Standard iPad Touch Icon-->
    <link rel="apple-touch-icon" sizes="72x72" href="http://placehold.it/72.png/000/fff">
    <!-- Standard iPhone Touch Icon-->
    <link rel="apple-touch-icon" sizes="57x57" href="http://placehold.it/57.png/000/fff">
    <!-- Styles -->
    <link href="../assets/css/lib/font-awesome.min.css" rel="stylesheet">
    <link href="../assets/css/lib/themify-icons.css" rel="stylesheet">
    <link href="../assets/css/lib/owl.carousel.min.css" rel="stylesheet" />
    <link href="../assets/css/lib/owl.theme.default.min.css" rel="stylesheet" />
    <link href="../assets/css/lib/weather-icons.css" rel="stylesheet" />
    <link href="../assets/css/lib/menubar/sidebar.css" rel="stylesheet">
    <link href="../assets/css/lib/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/lib/unix.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <link href="../assets/css/own.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">








</head>

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

<!-- Bootstrap JS -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

<body class="sidebar-hide">

    <?php require_once('../layouts/sidebar.php');

    ?>

    <?php require_once('../layouts/header.php'); ?>

    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-8 p-r-0 title-margin-right">
                        <div class="page-header">
                            <div class="page-title">
                                <h1>Hello, <span>Welcome Here</span></h1>
                            </div>
                        </div>
                    </div>
                    <!-- /# column -->
                    <div class="col-lg-4 p-l-0 title-margin-left">
                        <div class="page-header">
                            <div class="page-title">
                                <ol class="breadcrumb text-right">
                                    <li><a href="#">Dashboard</a></li>
                                    <li class="active">Home</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                    <!-- /# column -->
                </div>
                <!-- /# row -->

                <div class="container-fluid">
    <div class="row">
        <!-- Create Job Description -->
        <div class="col-lg-6">
            <div class="card alert">
                <div class="card-header">
                    <h4>Create Job Description</h4>
                    <div class="card-header-right-icon">
                        <ul>
                            <li class="card-close" data-dismiss="alert"><i class="ti-close"></i></li>
                            <li class="doc-link"><a href="#"><i class="ti-link"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="card-body">
                    <div class="horizontal-form">
                        <form class="form-horizontal" method='POST' role='form' action='co_add.php'>
                            <input type='hidden' name='in_Id' id='in_Id' class='form-control' type='text'>

                            <?php $conn = new mysqli('localhost', 'root', '', 'dola') or die('Cannot connect to db');
                                    $resul = $conn->query("select * from tbl_users where user_role_id like '%2%'");
                                    echo '<label>Select Company</label>';
                                    echo '<div class="form-group">';
                                    echo '<select class="form-control" id="apply_cp" name="in_CpName">';
                                    while ($row = mysqli_fetch_array($resul)) {
                                        echo "<option value=" . $row['first_name'] . ">" . $row['first_name'] . "</option>";
                                    }
                                    echo '</select>';
                                    echo '</div>';

                                    ?>
                                    <div class='form-group'>
                                        <label for='in_Position' >Position</label>
                                        <div >
                                            <input name='in_Position' id='in_Position' class='form-control' type='text'>
                                        </div>
                                    </div>

                                    <div class='form-group'>
                                        <label for='Qualification'>Qualification</label>
                                        <div>
                                            <input name='Qualification' id='Qualification' class='form-control' type='text'>
                                        </div>
                                    </div>

                                    <div class='form-group'>
                                        <label for='in_CanNum' >Vacancy No</label>
                                        <div >
                                            <input name='in_CanNum' id='in_CanNum' class='form-control' type='text'>
                                        </div>
                                    </div>

                                    <div class='form-group'>
                                        <label for='in_JobDetails'>Job Detials</label>
                                        <div >
                                            <textarea name='in_JobDetails' id='in_JobDetails' class='form-control' type='text' rows='5'></textarea>
                                        </div>
                                    </div>

                                    <div class='form-group'>
                                        <label for='in_Salary' >Salary</label>
                                        <div >
                                            <input name='in_Salary' id='in_Salary' class='form-control' type='text'>
                                        </div>
                                    </div>

                                    
                                    <div class="form-group">
                                        <label for="in_Insurance">Insurance Coverage</label>
                                        <div>
                                            <select name="in_Insurance" id="in_Insurance" class="form-control">
                                                <option value="Yes">Yes</option>
                                                <option value="No">No</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="in_Resident">Residential Fesilities</label>
                                        <div>
                                            <select name="in_Resident" id="in_Resident" class="form-control">
                                                <option value="Yes">Yes</option>
                                                <option value="No">No</option>
                                            </select>
                                        </div>
                                    </div>
                 
                                    <div class='form-group'>
                                        <label for='in_Email'>Email</label>
                                        <div>
                                            <input name='in_Email' id='in_Email' class='form-control' type='email'>
                                        </div>
                                    </div>
                            <div >
                                <input type="submit" value="Register" class="btn btn-primary">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

<!-- Bootstrap JS -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
        <script>
$(document).ready(function() {
    $(".view_vacancy, .edit_vacancy").click(function() {
        var companyId = $(this).data("id");
        var action = $(this).hasClass("view_vacancy") ? "view" : "edit";

        // AJAX request to load data
        $.ajax({
            type: "POST",
            url: "load_vacancy_details.php",
            data: { id: companyId, action: action },
            dataType: "json",
            success: function(response) {
                // Populate the form fields with the fetched data
                $("#in_Id").val(response.id);
                $("#apply_cp").val(response.cp_name);
                $("#in_Position").val(response.cp_position);
                $("#Qualification").val(response.qualification);
                $("#in_CanNum").val(response.can_number);
                $("#in_JobDetails").val(response.job_details);
                $("#in_Salary").val(response.salary);
                $("#in_Insurance").val(response.insurance);
                $("#in_Resident").val(response.resident);
                $("#in_Email").val(response.email);

                // Disable form fields for view mode
                if (action === "view") {
                    $(".form-control").prop("disabled", true);
                    $("input[type=submit]").hide();
                }

                // Show the form in a modal or however you prefer
                $("#yourModalId").modal("show");
            },
            error: function(error) {
                console.error("Error loading data: ", error);
            }
        });
    });
});
</script>
        <!-- /Create Job Description -->


<!-- Application List -->
<div class="col-lg-6">
    <div class="card alert">
        <div class="card-header">
            <h4>Application List</h4>
        </div>
        <div class="col-lg-6 text-right">
            <button class="btn btn-sm btn-primary" type="button" id="new_application">
                <i class="fa fa-plus"></i> New Applicant
            </button>
        </div>
    </div>

    <div class="card-body">
    <!-- Add the Application List code here -->

    <div class="card-header">
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-lg-6">
                <div class="row">
                    <div class="col-md-3 text-right">Position:</div>
                    <div class="col-md-5">
                        <select name="" class="custom-select browser-default select2" id="position_filter">
                            <option value="all" selected>All</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>

        <hr><br>
        <table class="table table-bordered table-hover">
            <colgroup>
                <col width="10%">
                <col width="30%">
                <col width="20%">
                <col width="30%">
            </colgroup>
            <thead>
                <tr>
                    <th class="text-center">#</th>
                    <th class="text-center">Applicant Information</th>
                    <th class="text-center">Availability</th>
                    <th class="text-center">Action</th>
                </tr>
            </thead>
            <?php
 //database connection here
include("config.php");

// Fetch data from the students table
$query = $dbConn->query("SELECT * FROM students");
$students = $query->fetchAll(PDO::FETCH_ASSOC);
?>

<tbody>
    <?php foreach ($students as $index => $student) : ?>
        <tr>
            <td class="text-center"><?php echo $index + 1; ?></td>
            <td class="">
                <p>Name : <b><?php echo $student['name']; ?></b></p>
                <p>Applied for : <b><?php echo $student['company_position']; ?></b></p>
            </td>
            <td class="text-center">
                <!-- Display any other relevant data here -->
            </td>
            <td class="text-center">
                <button class="btn btn-sm btn-primary view_application" type="button" data-id="<?php echo $student['id']; ?>">View</button>
                <button class="btn btn-sm btn-primary edit_application" type="button" data-id="<?php echo $student['id']; ?>">Edit</button>
                <button class="btn btn-sm btn-danger delete_application" type="button" data-id="<?php echo $student['id']; ?>">Delete</button>
            </td>
        </tr>
    <?php endforeach; ?>
</tbody>

        </table>
        <div class="text-center">
                <ul class="pagination" id="pagination"></ul>
            </div>
    </div>
</div>
<!-- /Application List -->
</div>
<!-- /# main -->
</div>
<script>
document.addEventListener("DOMContentLoaded", function () {
    const itemsPerPage = 10;
    const students = <?php echo json_encode($students); ?>;
    const totalItems = students.length;

    function displayItems(page) {
        const startIndex = (page - 1) * itemsPerPage;
        const endIndex = startIndex + itemsPerPage;

        const paginatedStudents = students.slice(startIndex, endIndex);

        const tableBody = document.querySelector("#applicantTable tbody");
        tableBody.innerHTML = '';

        paginatedStudents.forEach((student, index) => {
            const row = document.createElement("tr");
            // Populate the row with student information
            row.innerHTML = `<td class="text-center">${startIndex + index + 1}</td><td>
                <p>Name : <b>${student.name}</b></p>
                <p>Applied for : <b>${student.company_position}</b></p>
            </td>
            <td class="text-center">
                <!-- Display any other relevant data here -->
            </td>
            <td class="text-center">
                <button class="btn btn-sm btn-primary view_application" type="button" data-id="${student.id}">View</button>
                <button class="btn btn-sm btn-primary edit_application" type="button" data-id="${student.id}">Edit</button>
                <button class="btn btn-sm btn-danger delete_application" type="button" data-id="${student.id}">Delete</button>
            </td>`;
            tableBody.appendChild(row);
        });
    }

    function displayPagination() {
        const totalPages = Math.ceil(totalItems / itemsPerPage);
        const paginationElement = document.querySelector("#pagination");
        paginationElement.innerHTML = '';

        for (let i = 1; i <= totalPages; i++) {
            const listItem = document.createElement("li");
            listItem.className = "page-item";
            listItem.innerHTML = `<a class="page-link" href="javascript:void(0);" onclick="changePage(${i})">${i}</a>`;
            paginationElement.appendChild(listItem);
        }
    }

    function changePage(page) {
        displayItems(page);
        updateActivePage(page);
    }

    function updateActivePage(page) {
        const paginationElement = document.querySelector("#pagination");
        const pages = paginationElement.querySelectorAll(".page-item");

        pages.forEach((item, index) => {
            item.classList.remove("active");
            if (index + 1 === page) {
                item.classList.add("active");
            }
        });
    }

    displayItems(1);
    displayPagination();
});

</script>

<!-- /# content wrap -->
        <!-- /# content wrap -->

 <!-- Company List Section -->
 <?php
include("config.php");

// method to retrieve company data from the database
$query = $dbConn->query("SELECT * FROM tbl_company");
$companyData = $query->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container-fluid">
    <div class="col-lg-12">
        <div class="row">
            <!-- Table Panel -->
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-lg-12">
                                <span><large><b>Vacancy List</b></large></span>
                                <button class="btn btn-sm btn-block btn-primary btn-sm col-md-2 float-right" type="button" id="new_vacancy"><i class="fa fa-plus"></i> New Vacancy</button>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-hover">
                            <colgroup>
                                <col width="10%">
                                <col width="40%">
                                <col width="20%">
                                <col width="10%">
                                <col width="20%">
                            </colgroup>
                            <thead>
                                <tr>
                                    <th class="text-center">#</th>
                                    <th class="text-center">Company Information</th>
                                    <th class="text-center">Availability</th>
                                    <th class="text-center">Status</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($companyData as $index => $row): ?>
                                    <tr>
                                        <td class="text-center"><?php echo $index + 1; ?></td>
                                        <td class="">
                                            <p>Company Name : <b><?php echo $row['cp_name']; ?></b></p>
                                            <p>Position : <b><?php echo $row['cp_position']; ?></b></p>
                                            <p class=" truncate">Job Details: <i><small><?php echo $row['job_details']; ?></small></i></p>
                                        </td>
                                        <td class="text-center">
                                            <p><b><?php echo $row['can_number']; ?></b></p>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge badge-success">Active</span>
                                        </td>
                                        <td class="text-center">
                                            <!-- Modify data-id to use the actual company ID -->
                                            <button class="btn btn-sm btn-primary view_vacancy" type="button" data-id="<?php echo $row['id']; ?>" >View</button>
                                            <button class="btn btn-sm btn-primary edit_vacancy" type="button" data-id="<?php echo $row['id']; ?>" >Edit</button>
                                            <button class="btn btn-sm btn-danger delete_vacancy" type="button" data-id="<?php echo $row['id']; ?>">Delete</button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- Table Panel -->
        </div>
    </div>
</div>

<style>
    td{
        vertical-align: middle !important;
    }
    td p{
        margin: unset;
    }
    img{
        max-width: 100px;
        max-height: 150px;
    }
</style>

<script>
    $(document).ready(function () {
    var companyId;

    // Function to handle modal show event
    $('#vacancyModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget);
        companyId = button.data('id');
        var action = button.hasClass('view_vacancy') ? 'view' : 'edit';

        // AJAX request to load data
        $.ajax({
            type: 'POST',
            url: 'load_vacancy_details.php',
            data: { id: companyId, action: action },
            dataType: 'json',
            success: function (response) {
                populateFormFields(response, action === 'view');
            },
            error: function (error) {
                console.error('Error loading data: ', error);
            }
        });
    });

    // Function to populate form fields
    function populateFormFields(data, isViewMode) {
        $('#in_Id').val(data.id);
        $('#apply_cp').val(data.cp_name);
        $('#in_Position').val(data.cp_position);
        $('#Qualification').val(data.qualification);
        $('#in_CanNum').val(data.can_number);
        $('#in_JobDetails').val(data.job_details);
        $('#in_Salary').val(data.salary);
        $('#in_Insurance').val(data.insurance);
        $('#in_Resident').val(data.resident);
        $('#in_Email').val(data.email);

        // Enable form fields for editing
        if (!isViewMode) {
            $('.form-control').prop('disabled', false);
            $('input[type=submit]').show();
        } else {
            // Disable form fields for view mode
            $('.form-control').prop('disabled', true);
            $('input[type=submit]').hide();
        }
    }

    // Event listener for the update button inside the modal
    $('#updateButton').click(function () {
        // Handle the update logic here
        if (companyId !== undefined) {
            alert('Update button clicked for company with ID: ' + companyId);
            // You can use AJAX to send the updated data to the server
            // and then reload the table or perform other necessary actions
        } else {
            console.error('Invalid company ID');
        }
    });
});


</script>





<script>
// Function to delete vacancy
function deleteVacancy(id) {
    if (confirm("Are you sure you want to delete this vacancy?")) {
        $.ajax({
            type: "POST",
            url: "delete_vacancy.php",
            data: { id: id },
            dataType: "json",
            success: function(response) {
                if (response.success) {
                    alert(response.success);
                    // Implement logic to update the table or UI accordingly
                } else {
                    alert(response.error);
                }
            },
            error: function(error) {
                console.error("Error deleting vacancy: ", error);
            }
        });
    }
}

// Delete button click event
$(".delete_vacancy").click(function() {
    var companyId = $(this).data("id");
    deleteVacancy(companyId);
});
</script>
<!-- Modal -->


<!-- /Company List Section -->

        <div id="search">
            <button type="button" class="close">×</button>
            <form>
                <input type="search" value="" placeholder="type keyword(s) here" />
                <button type="submit" class="btn btn-primary">Search</button>
            </form>
        </div>
        <!-- jquery vendor -->
        <script src="../assets/js/lib/jquery.min.js"></script>
        <script src="../assets/js/lib/jquery.nanoscroller.min.js"></script>
        <!-- nano scroller -->
        <script src="../assets/js/lib/menubar/sidebar.js"></script>
        <script src="../assets/js/lib/preloader/pace.min.js"></script>
        <!-- sidebar -->
        <script src="../assets/js/lib/bootstrap.min.js"></script>
        <!-- bootstrap -->
        <script src="../assets/js/lib/mmc-common.js"></script>
        <script src="../assets/js/lib/mmc-chat.js"></script>
        <!--  Chart js -->
        <script src="../assets/js/lib/chart-js/Chart.bundle.js"></script>
        <script src="../assets/js/lib/chart-js/chartjs-init.js"></script>
        <!-- // Chart js -->

        <!--  Datamap -->
        <script src="../assets/js/lib/datamap/d3.min.js"></script>
        <script src="../assets/js/lib/datamap/topojson.js"></script>
        <script src="../assets/js/lib/datamap/datamaps.world.min.js"></script>
        <script src="../assets/js/lib/datamap/datamap-init.js"></script>
        <!-- // Datamap -->
        <script src="../assets/js/lib/weather/jquery.simpleWeather.min.js"></script>
        <script src="../assets/js/lib/weather/weather-init.js"></script>
        <script src="../assets/js/lib/owl-carousel/owl.carousel.min.js"></script>
        <script src="../assets/js/lib/owl-carousel/owl.carousel-init.js"></script>
        <script src="../assets/js/scripts.js"></script>
        <!-- scripit init-->
<!-- Modal -->
<div class="modal fade" id="vacancyModal" tabindex="-1" role="dialog" aria-labelledby="vacancyModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="vacancyModalLabel">View/Edit Vacancy</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            <form class="form-horizontal" method='POST' role='form' action='co_add.php'>
                            <input type='hidden' name='in_Id' id='in_Id' class='form-control' type='text'>

                            
                                    <div class='form-group'>
                                        <label for='in_Position' >Position</label>
                                        <div >
                                            <input name='in_Position' id='in_Position' class='form-control' type='text'>
                                        </div>
                                    </div>

                                    <div class='form-group'>
                                        <label for='Qualification'>Qualification</label>
                                        <div>
                                            <input name='Qualification' id='Qualification' class='form-control' type='text'>
                                        </div>
                                    </div>

                                    <div class='form-group'>
                                        <label for='in_CanNum' >Vacancy No</label>
                                        <div >
                                            <input name='in_CanNum' id='in_CanNum' class='form-control' type='text'>
                                        </div>
                                    </div>

                                    <div class='form-group'>
                                        <label for='in_JobDetails'>Job Detials</label>
                                        <div >
                                            <textarea name='in_JobDetails' id='in_JobDetails' class='form-control' type='text' rows='5'></textarea>
                                        </div>
                                    </div>

                                    <div class='form-group'>
                                        <label for='in_Salary' >Salary</label>
                                        <div >
                                            <input name='in_Salary' id='in_Salary' class='form-control' type='text'>
                                        </div>
                                    </div>

                                    
                                    <div class="form-group">
                                        <label for="in_Insurance">Insurance Coverage</label>
                                        <div>
                                            <select name="in_Insurance" id="in_Insurance" class="form-control">
                                                <option value="Yes">Yes</option>
                                                <option value="No">No</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="in_Resident">Residential Fesilities</label>
                                        <div>
                                            <select name="in_Resident" id="in_Resident" class="form-control">
                                                <option value="Yes">Yes</option>
                                                <option value="No">No</option>
                                            </select>
                                        </div>
                                    </div>
                 
                                    <div class='form-group'>
                                        <label for='in_Email'>Email</label>
                                        <div>
                                            <input name='in_Email' id='in_Email' class='form-control' type='email'>
                                        </div>
                                    </div>
                            <div >
                                <input type="submit" value="Register" class="btn btn-primary">
                            </div>
                        </form>
            </div>
            <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="updateButton">Update</button>
    </div>
        </div>
    </div>
</div>

        <script>
$(document).ready(function() {
    $(".view_vacancy, .edit_vacancy").click(function() {
        var companyId = $(this).data("id");
        var action = $(this).hasClass("view_vacancy") ? "view" : "edit";

        // AJAX request to load data
        $.ajax({
            type: "POST",
            url: "load_vacancy_details.php",
            data: { id: companyId, action: action },
            dataType: "json",
            success: function(response) {
                // Populate the form fields with the fetched data
                $("#in_Id").val(response.id);
                $("#apply_cp").val(response.cp_name);
                $("#in_Position").val(response.cp_position);
                $("#Qualification").val(response.qualification);
                $("#in_CanNum").val(response.can_number);
                $("#in_JobDetails").val(response.job_details);
                $("#in_Salary").val(response.salary);
                $("#in_Insurance").val(response.insurance);
                $("#in_Resident").val(response.resident);
                $("#in_Email").val(response.email);

                // Disable form fields for view mode
                if (action === "view") {
                    $(".form-control").prop("disabled", true);
                    $("input[type=submit]").hide();
                }

                // Show the form in a modal or however you prefer
                $("#vacancyModal").modal("show");

            },
            error: function(error) {
                console.error("Error loading data: ", error);
            }
        });
    });
});
</script>


    
</body>
</html>