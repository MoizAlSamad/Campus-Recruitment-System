<?php
include("config.php");

$id = $_GET['id']; // Use $_GET to retrieve parameters from the URL
$user_role_id = $_GET['user_role_id'];
$first_name = $_GET['first_name'];
$last_name = $_GET['last_name'];
$email = $_GET['email'];

$sql = "UPDATE tbl_users SET user_role_id=:user_role_id, first_name=:first_name, last_name=:last_name, email=:email WHERE id=:id";
$query = $dbConn->prepare($sql);
$query->bindparam(':id', $id);
$query->bindparam(':user_role_id', $user_role_id);
$query->bindparam(':first_name', $first_name);
$query->bindparam(':last_name', $last_name);
$query->bindparam(':email', $email);
$query->execute();

$dbConn = null;
header("Location:../admin/index.php");
?>


